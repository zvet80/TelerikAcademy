﻿//Problem 1.JavaScript literals

var int = 100,
    float = 0.2,
    bool = true,
    string = 'some text',
    array = [1, 2, 3],
    object = { student: 'Pesho', js: 5 },
    variable = null,
    undefinedvalue = undefined;

//Problem 2. Quoted text

var quatedText = '\'How you doin\'?\', Joey said';
console.log(quatedText);

////Problem 3. Typeof variables
var typeofInt = typeof (int);
var typeofFloat = typeof (float);
var typeofBool = typeof (bool);
var typeofString = typeof (string);
var typeofArr = typeof (array);
var typeofObj = typeof (object);


//Problem 4. Typeof null
var typeofnull = typeof (variable);
var typeofundefined = typeof (undefinedvalue);